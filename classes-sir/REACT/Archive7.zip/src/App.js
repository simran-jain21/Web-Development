import logo from './logo.svg';
import './App.css';
import FormComponent from './FormComponent';

function App() {
  return (
    <div className="">
      <FormComponent/>
    </div>
  );
}

export default App;

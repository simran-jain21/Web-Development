import React from 'react'
import CompB from './CompB'

const CompA = (props) => {
  return (
    <div>
        <CompB/>
    </div>
  )
}

export default CompA
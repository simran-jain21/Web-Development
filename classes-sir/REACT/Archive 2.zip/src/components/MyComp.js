import React from 'react'

export const MyComp1 = () => {
  return (
    <div>This is first component </div>
  )
}



export const MyComp2 = () => {
  return (
    <div>This is second component </div>
  )
}

 const MyCom3 = ()=>{
  return (
    <div>back</div>
  )
}

export default MyCom3;
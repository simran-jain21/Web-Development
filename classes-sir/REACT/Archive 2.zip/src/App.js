
import './App.css';
// import FirstComponent from './components/FirstComponent';
// import SecondComponent from "./components/SecondComponent";
// import MyCom3, {MyComp1, MyComp2} from './components/MyComp'
import ApiComponent from './components/ApiComponent'

function App() {
  return (
    <>
       <h1>Hello</h1>
      {/* <FirstComponent/>
      <SecondComponent/>
      <MyComp1/>
      <MyComp2/>
      <MyCom3/> */}
<ApiComponent/>
    </>
  );
}

export default App;

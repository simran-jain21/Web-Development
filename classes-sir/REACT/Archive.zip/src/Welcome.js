import React from 'react'

const Welcome = () => {
  return (
    <div style={{border:'2px solid red',borderRadius:'3px'}}>
        <h1>Welcom to your React App</h1>
    </div>
  )
}

export default Welcome